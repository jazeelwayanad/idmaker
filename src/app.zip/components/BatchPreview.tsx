import React, { useState, useEffect, useRef } from 'react';
import { useStore, Student } from '../hooks/useStore';
import { loadTemplateToCanvas } from '../utils/canvasHelper';
import * as fabric from 'fabric';
import { 
  Play, Download, CheckSquare, Square, AlertTriangle, Eye, ShieldAlert,
  Search, Filter, ChevronLeft, ChevronRight, FileDown, FolderOpen,
  Settings, Check, X, HardDrive, Hourglass, Zap, Folder, Plus, Minus
} from 'lucide-react';

if (fabric.FabricObject) {
  (fabric.FabricObject as any).customProperties = [
    'name',
    'photoShape',
    'photoRx',
    'photoRy',
    'photoStroke',
    'photoStrokeWidth',
    'photoFill',
    'isAppBackground'
  ];
}

type RecordFilter = 'all' | 'matched' | 'missing' | 'selected';

export default function BatchPreview() {
  const { 
    students, activeTemplate, mappedFields, activeStudentIndex, 
    setStudentIndex, nextStudent, prevStudent, fetchExports, exports, activeProject
  } = useStore();

  const [selectedStudents, setSelectedStudents] = useState<Record<number, boolean>>({});
  const [filterText, setFilterText] = useState('');
  const [recordFilter, setRecordFilter] = useState<RecordFilter>('all');
  const [exportType, setExportType] = useState<'png' | 'pdf' | 'both'>('pdf');
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [cardsPerSecond, setCardsPerSecond] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const [namingPattern, setNamingPattern] = useState('[RegisterNo]_[Name]');
  const [zoom, setZoom] = useState(1);
  const [exportFolder, setExportFolder] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('idmaker_export_folder');
      if (saved) setExportFolder(saved);
    }
  }, []);

  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const hiddenCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fabricPreviewRef = useRef<fabric.Canvas | null>(null);
  const fabricHiddenRef = useRef<fabric.Canvas | null>(null);

  const DPI = 300;
  const MM_TO_PX = DPI / 25.4;
  const cardW = Math.round((activeTemplate?.width || 85.6) * MM_TO_PX);
  const cardH = Math.round((activeTemplate?.height || 53.98) * MM_TO_PX);
  const displayScale = Math.min(480 / cardW, 340 / cardH, 0.65);

  const getDesignJson = (template: any): string => {
    if (!template) return '{}';
    let design = template.frontDesign || '{}';
    if (design.startsWith('[')) {
      try {
        const list = JSON.parse(design);
        design = list[0] || '{}';
      } catch (e) {}
    }
    return design;
  };

  const handleSelectExportFolder = async () => {
    if (typeof window === 'undefined' || !window.api) return;
    try {
      const folder = await window.api.files.selectFolder();
      if (folder) {
        setExportFolder(folder);
        localStorage.setItem('idmaker_export_folder', folder);
      }
    } catch (e) {
      console.error('Failed to select folder:', e);
    }
  };

  const handleClearExportFolder = () => {
    setExportFolder(null);
    localStorage.removeItem('idmaker_export_folder');
  };

  useEffect(() => {
    if (!previewCanvasRef.current || !hiddenCanvasRef.current || !activeTemplate) return;

    const pCanvas = new fabric.Canvas(previewCanvasRef.current, {
      width: cardW * displayScale,
      height: cardH * displayScale,
      backgroundColor: '#18181b',
      selection: false,
      interactive: false
    });
    fabricPreviewRef.current = pCanvas;

    const hCanvas = new fabric.Canvas(hiddenCanvasRef.current, {
      width: cardW,
      height: cardH,
      backgroundColor: '#18181b',
      selection: false
    });
    fabricHiddenRef.current = hCanvas;

    const checks: Record<number, boolean> = {};
    students.forEach(s => {
      checks[s.id] = true;
    });
    setSelectedStudents(checks);

    return () => {
      pCanvas.dispose();
      hCanvas.dispose();
      fabricPreviewRef.current = null;
      fabricHiddenRef.current = null;
    };
  }, [students.length, activeTemplate?.id, cardW, cardH]);

  useEffect(() => {
    const canvas = fabricPreviewRef.current;
    if (!canvas) return;
 canvas.setZoom(1);

canvas.setDimensions({
    width: cardW * displayScale,
    height: cardH * displayScale
});
    canvas.renderAll();
    if (students.length > 0) {
      renderPreview(students[activeStudentIndex]);
    }
  }, [zoom, cardW, cardH, displayScale]);

  useEffect(() => {
    if (students.length > 0 && fabricPreviewRef.current) {
      renderPreview(students[activeStudentIndex]);
    }
  }, [activeStudentIndex, students.length, activeTemplate?.frontDesign]);

  const renderPreview = async (student: Student | undefined) => {
    const canvas = fabricPreviewRef.current;
    if (!canvas || !activeTemplate || !student) return;

    const design = getDesignJson(activeTemplate);
    await loadTemplateToCanvas(canvas, design, cardW, cardH, {
      isPreview: true,
      displayScale: displayScale
    });
    if (fabricPreviewRef.current !== canvas) return;

    canvas.clipPath = new fabric.Rect({
      left: 0, top: 0,
      width: canvas.width, height: canvas.height,
      absolutePositioned: true
    });
      
      const objects = canvas.getObjects();
      const studentData = JSON.parse(student.data || '{}');

      for (const obj of objects) {
        if (obj.type === 'textbox' || obj.type === 'text' || obj.type === 'i-text') {
          const textObj = obj as fabric.Textbox;
          let val = textObj.text || '';
          const matches = val.match(/\{[^}]+\}/g);
          if (matches) {
            matches.forEach(m => {
              const colKey = mappedFields[m] || m.replace('{', '').replace('}', '');
              const replacement = studentData[colKey] || '';
              val = val.replace(m, replacement);
            });
            textObj.set('text', val);
          }
        }

        const isPhoto = (obj as any).name === '{Photo}' || 
                        (obj instanceof fabric.Group && (obj as fabric.Group).getObjects().some(o => (o as any).text === '{Photo}' || (o as any).name === '{Photo}'));
        if (isPhoto && student.photoPath) {
          let left = obj.left;
          let top = obj.top;
          let width = obj.width * obj.scaleX!;
          let height = obj.height * obj.scaleY!;
          
          let photoShape = (obj as any).photoShape || 'rect';
          let rx = (obj as any).photoRx !== undefined ? (obj as any).photoRx : 8;
          let ry = (obj as any).photoRy !== undefined ? (obj as any).photoRy : 8;
          let stroke = (obj as any).photoStroke || '#0284c7';
          let strokeWidth = (obj as any).photoStrokeWidth !== undefined ? (obj as any).photoStrokeWidth : 2;

          if (obj instanceof fabric.Group) {
            const rectObj = obj.getObjects().find(o => o instanceof fabric.Rect || o instanceof fabric.Circle);
            if (rectObj) {
              width = rectObj.width * rectObj.scaleX! * obj.scaleX!;
              height = rectObj.height * rectObj.scaleY! * obj.scaleY!;
            }
          }

          try {
            const normalizedPath = student.photoPath.replace(/\\/g, '/');
            const localPhotoUrl = `local-photo://load/${normalizedPath}`;
            const img = await fabric.Image.fromURL(localPhotoUrl);
            const scale = Math.max(width / img.width!, height / img.height!);
            
            let clip;
            let borderObj;

            if (photoShape === 'circle') {
              const radius = Math.min(width, height) / 2;
              clip = new fabric.Circle({
                left: left, top: top,
                radius: radius, absolutePositioned: true
              });
              if (strokeWidth > 0) {
                borderObj = new fabric.Circle({
                  left: left, top: top,
                  radius: radius - strokeWidth / 2,
                  fill: 'transparent', stroke: stroke, strokeWidth: strokeWidth,
                  selectable: false, evented: false
                });
              }
            } else {
              clip = new fabric.Rect({
                left: left, top: top,
                width: width, height: height,
                rx: rx * obj.scaleX!, ry: ry * obj.scaleY!,
                absolutePositioned: true
              });
              if (strokeWidth > 0) {
                borderObj = new fabric.Rect({
                  left: left, top: top,
                  width: width, height: height,
                  rx: rx * obj.scaleX!, ry: ry * obj.scaleY!,
                  fill: 'transparent', stroke: stroke, strokeWidth: strokeWidth,
                  selectable: false, evented: false
                });
              }
            }

            img.set({
              left: left + (width - img.width! * scale) / 2,
              top: top + (height - img.height! * scale) / 2,
              scaleX: scale, scaleY: scale,
              clipPath: clip
            });

            canvas.remove(obj);
            canvas.add(img);
            if (borderObj) canvas.add(borderObj);
          } catch (e) {
            console.error(e);
          }
        }
      }
      canvas.renderAll();
  };

  const generateHighResCard = async (student: Student): Promise<string | null> => {
    const canvas = fabricHiddenRef.current;
    if (!canvas || !activeTemplate) return null;

    const scaleMultiplier = 1 / displayScale;
    const design = getDesignJson(activeTemplate);
    const designHash = design.length + '_' + design.substring(0, 20) + '_' + design.substring(Math.max(0, design.length - 20));
    const cacheKey = `${activeTemplate.id}_0_${designHash}`;
    const isLoaded = (canvas as any).currentCacheKey === cacheKey;

    if (!isLoaded) {
      try {
        await loadTemplateToCanvas(canvas, design, cardW, cardH, {
          isPreview: false,
          displayScale: displayScale
        });
        if (fabricHiddenRef.current !== canvas) return null;

        canvas.setDimensions({ width: cardW, height: cardH });

        const objects = canvas.getObjects();
        objects.forEach(obj => {
          if (obj.type === 'textbox' || obj.type === 'text' || obj.type === 'i-text') {
            (obj as any).originalText = (obj as any).text;
          }
        });

        canvas.clipPath = new fabric.Rect({
          left: 0, top: 0,
          width: cardW, height: cardH,
          absolutePositioned: true
        });

        (canvas as any).currentCacheKey = cacheKey;
      } catch (err) {
        console.error(err);
        return null;
      }
    }

    const objects = canvas.getObjects();
    const dynamicObjects = objects.filter(obj => (obj as any).isDynamicPhoto);
    dynamicObjects.forEach(obj => canvas.remove(obj));

    objects.forEach(obj => {
      if (obj.type === 'textbox' || obj.type === 'text' || obj.type === 'i-text') {
        if ((obj as any).originalText !== undefined) {
          (obj as any).text = (obj as any).originalText;
        }
      }
      const isPhoto = (obj as any).name === '{Photo}' || 
                      (obj instanceof fabric.Group && (obj as fabric.Group).getObjects().some(o => (o as any).text === '{Photo}' || (o as any).name === '{Photo}'));
      if (isPhoto) {
        obj.set({ visible: true });
      }
    });

    try {
      const studentData = JSON.parse(student.data || '{}');

      for (const obj of objects) {
        if (!obj.visible) continue;

        if (obj.type === 'textbox' || obj.type === 'text' || obj.type === 'i-text') {
          const textObj = obj as fabric.Textbox;
          let val = textObj.text || '';
          const matches = val.match(/\{[^}]+\}/g);
          if (matches) {
            matches.forEach(m => {
              const colKey = mappedFields[m] || m.replace('{', '').replace('}', '');
              const replacement = studentData[colKey] || '';
              val = val.replace(m, replacement);
            });
            textObj.set('text', val);
          }
        }

        const isPhoto = (obj as any).name === '{Photo}' || 
                        (obj instanceof fabric.Group && (obj as fabric.Group).getObjects().some(o => (o as any).text === '{Photo}' || (o as any).name === '{Photo}'));
        if (isPhoto && student.photoPath) {
          let left = obj.left;
          let top = obj.top;
          let width = obj.width * obj.scaleX!;
          let height = obj.height * obj.scaleY!;
          
          let photoShape = (obj as any).photoShape || 'rect';
          let rx = (obj as any).photoRx !== undefined ? (obj as any).photoRx : 8;
          let ry = (obj as any).photoRy !== undefined ? (obj as any).photoRy : 8;
          let stroke = (obj as any).photoStroke || '#0284c7';
          let strokeWidth = (obj as any).photoStrokeWidth !== undefined ? (obj as any).photoStrokeWidth : 2;

          if (obj instanceof fabric.Group) {
            const rectObj = obj.getObjects().find(o => o instanceof fabric.Rect || o instanceof fabric.Circle);
            if (rectObj) {
              width = rectObj.width * rectObj.scaleX! * obj.scaleX!;
              height = rectObj.height * rectObj.scaleY! * obj.scaleY!;
            }
          }

          try {
            const normalizedPath = student.photoPath.replace(/\\/g, '/');
            const localPhotoUrl = `local-photo://load/${normalizedPath}`;
            const img = await fabric.Image.fromURL(localPhotoUrl);
            const scale = Math.max(width / img.width!, height / img.height!);
            
            let clip;
            let borderObj;

            if (photoShape === 'circle') {
              const radius = Math.min(width, height) / 2;
              clip = new fabric.Circle({
                left: left, top: top,
                radius: radius, absolutePositioned: true
              });
              if (strokeWidth > 0) {
                borderObj = new fabric.Circle({
                  left: left, top: top,
                  radius: radius - strokeWidth / 2,
                  fill: 'transparent', stroke: stroke, strokeWidth: strokeWidth,
                  selectable: false, evented: false
                });
              }
            } else {
              clip = new fabric.Rect({
                left: left, top: top,
                width: width, height: height,
                rx: rx * obj.scaleX!, ry: ry * obj.scaleY!,
                absolutePositioned: true
              });
              if (strokeWidth > 0) {
                borderObj = new fabric.Rect({
                  left: left, top: top,
                  width: width, height: height,
                  rx: rx * obj.scaleX!, ry: ry * obj.scaleY!,
                  fill: 'transparent', stroke: stroke, strokeWidth: strokeWidth,
                  selectable: false, evented: false
                });
              }
            }

            img.set({
              left: left + (width - img.width! * scale) / 2,
              top: top + (height - img.height! * scale) / 2,
              scaleX: scale, scaleY: scale,
              clipPath: clip
            });

            obj.set({ visible: false });
            (img as any).isDynamicPhoto = true;
            canvas.add(img);
            if (borderObj) {
              (borderObj as any).isDynamicPhoto = true;
              canvas.add(borderObj);
            }
          } catch (e) {
            console.error(e);
          }
        }
      }

      canvas.renderAll();
      return canvas.toDataURL({ format: 'png', multiplier: 1 });
    } catch (err) {
      console.error(err);
      return null;
    }
  };

  const toggleSelectAll = () => {
    const next: Record<number, boolean> = {};
    const allChecked = Object.values(selectedStudents).every(v => v);
    students.forEach(s => { next[s.id] = !allChecked; });
    setSelectedStudents(next);
  };

  const handleCheckboxChange = (id: number) => {
    setSelectedStudents(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getFormattedFilename = (student: Student, extension: string) => {
    const data = JSON.parse(student.data || '{}');
    let output = namingPattern;
    const matches = output.match(/\[[^\]]+\]/g);
    if (matches) {
      matches.forEach(m => {
        const key = m.substring(1, m.length - 1);
        const replacement = data[key] || student[key as keyof Student] || '';
        output = output.replace(m, String(replacement).replace(/[^a-zA-Z0-9_-]/g, '_'));
      });
    }
    if (!output.trim()) output = student.registerNo || `card_${student.id}`;
    return `${output}.${extension}`;
  };

  const handleBulkExport = async () => {
    const listToGenerate = students.filter(s => selectedStudents[s.id]);
    if (listToGenerate.length === 0) {
      alert('Please select at least one record to export.');
      return;
    }

    if (typeof window === 'undefined' || !window.api) return;

    setGenerating(true);
    setProgress(0);
    setCardsPerSecond(0);
    const startTime = Date.now();

    try {
      const generatedCards: { front: string; back?: string; allSides: string[]; data: any }[] = [];

      for (let i = 0; i < listToGenerate.length; i++) {
        const student = listToGenerate[i];
        const img = await generateHighResCard(student);
        if (img) {
          generatedCards.push({
            front: img,
            allSides: [img],
            data: JSON.parse(student.data || '{}')
          });
        }
        const elapsed = (Date.now() - startTime) / 1000;
        setElapsedSeconds(Math.round(elapsed));
        setCardsPerSecond(Number(((i + 1) / Math.max(0.1, elapsed)).toFixed(1)));
        setProgress(Math.round(((i + 1) / listToGenerate.length) * 50));
      }

      if (exportType === 'pdf' || exportType === 'both') {
        const docSettings = {
          paperSize: activeTemplate?.paperSize || 'A4',
          layout: activeTemplate?.layout ? JSON.parse(activeTemplate.layout) : { rows: 4, cols: 2, margin: 10, spacing: 5, showCropMarks: true },
          cardSize: { width: activeTemplate?.width || 85.6, height: activeTemplate?.height || 53.98 }
        };

        let exportName = activeTemplate?.name || 'ID_Cards';
        if (activeProject?.settings) {
          try {
            const settings = JSON.parse(activeProject.settings);
            if (settings.excelName) exportName = settings.excelName;
          } catch {}
        }

        const targetFile = `${exportName}.pdf`;
        const savePath = await window.api.files.saveFile(targetFile, '', undefined, exportFolder || undefined);
        if (savePath) {
          await window.api.files.exportPdf(savePath, docSettings, generatedCards);
          await window.api.exports.create({
            projectId: activeTemplate?.projectId,
            filename: targetFile,
            filePath: savePath,
            type: 'PDF Print Sheet',
            count: listToGenerate.length
          });
          await fetchExports();
        }
      }

      if (exportType === 'png' || exportType === 'both') {
        let exportName = activeTemplate?.name || 'ID_Cards';
        if (activeProject?.settings) {
          try {
            const settings = JSON.parse(activeProject.settings);
            if (settings.excelName) exportName = settings.excelName;
          } catch {}
        }
        const zipName = `${exportName}_Images.zip`;
        const savePath = await window.api.files.saveFile(zipName, '', undefined, exportFolder || undefined);
        
        if (savePath) {
          const zipFiles: { name: string; buffer: ArrayBuffer }[] = [];
          for (let idx = 0; idx < generatedCards.length; idx++) {
            const card = generatedCards[idx];
            const originalStudent = listToGenerate[idx];
            const baseName = getFormattedFilename(originalStudent, 'png').replace('.png', '');
            const buf = Buffer.from(card.front.replace(/^data:image\/\w+;base64,/, ""), 'base64');
            zipFiles.push({
              name: `${baseName}.png`,
              buffer: buf.buffer
            });
          }
          await window.api.files.exportZip(savePath, zipFiles);
          await window.api.exports.create({
            projectId: activeTemplate?.projectId,
            filename: zipName,
            filePath: savePath,
            type: 'ZIP Bundle',
            count: listToGenerate.length
          });
          await fetchExports();
        }
      }
      setProgress(100);
      alert('Bulk generation completed successfully!');
    } catch (err) {
      console.error(err);
      alert('An error occurred during card generation.');
    } finally {
      setGenerating(false);
    }
  };

  const handleOpenFolder = async (filePath: string) => {
    if (typeof window === 'undefined' || !window.api) return;
    const dir = filePath.substring(0, filePath.lastIndexOf('\\'));
    await window.api.files.openDirectory(dir);
  };

  const handleSingleExport = async (student: Student) => {
    if (typeof window === 'undefined' || !window.api || !activeTemplate) return;

    setGenerating(true);
    setProgress(0);

    try {
      const img = await generateHighResCard(student);
      if (!img) {
        alert('Could not render card layout.');
        return;
      }
      const cleanName = getFormattedFilename(student, 'png').replace('.png', '');
      const targetFile = `${cleanName}.png`;
      const base64Clean = img.replace(/^data:image\/\w+;base64,/, "");
      const savePath = await window.api.files.saveFile(targetFile, base64Clean, 'base64');
      
      if (savePath) {
        await window.api.exports.create({
          projectId: activeTemplate?.projectId,
          filename: targetFile,
          filePath: savePath,
          type: 'Single PNG Image',
          count: 1
        });
        await fetchExports();
        alert('Card exported as PNG successfully!');
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while exporting the card.');
    } finally {
      setGenerating(false);
    }
  };

  const getFilteredStudents = () => {
    let list = students.filter(s => 
      s.name.toLowerCase().includes(filterText.toLowerCase()) || 
      s.registerNo.toLowerCase().includes(filterText.toLowerCase())
    );
    if (recordFilter === 'matched') list = list.filter(s => s.photoPath);
    else if (recordFilter === 'missing') list = list.filter(s => !s.photoPath);
    else if (recordFilter === 'selected') list = list.filter(s => selectedStudents[s.id]);
    return list;
  };

  const filteredStudents = getFilteredStudents();

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-120px)] overflow-hidden bg-[#0e0e10] p-1 rounded-2xl">
      {/* COLUMN 1: STUDENT DIRECTORY (no highlight borders, flat background cards) */}
      <div className="w-full lg:w-80 flex flex-col rounded-2xl bg-[#141416] overflow-hidden shrink-0 shadow-lg">
        <div className="p-4 space-y-3 bg-[#121214]/50">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-zinc-200 text-xs uppercase tracking-wider">Select Records</h3>
            <button onClick={toggleSelectAll} className="text-[10px] uppercase font-bold text-primary-400 hover:text-primary-300 transition-colors">
              Toggle All
            </button>
          </div>
          <div className="flex items-center gap-2 bg-dark-800 rounded-xl px-3 py-2 text-xs">
            <Search className="w-4 h-4 text-zinc-500 shrink-0" />
            <input
              type="text"
              placeholder="Search by name, roll..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="bg-transparent border-none text-zinc-250 outline-none w-full text-xs"
            />
          </div>
          <div className="flex gap-1 overflow-x-auto pb-1">
            {(['all', 'matched', 'missing', 'selected'] as RecordFilter[]).map((f) => (
              <button
                key={f}
                onClick={() => setRecordFilter(f)}
                className={`px-2.5 py-1 rounded-lg text-[9px] font-bold uppercase transition-all ${
                  recordFilter === f ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-550 hover:text-zinc-350'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
          {filteredStudents.map((s) => {
            const isSelected = selectedStudents[s.id];
            const isViewing = activeStudentIndex === students.indexOf(s);
            return (
              <div 
                key={s.id}
                onClick={() => setStudentIndex(students.indexOf(s))}
                className={`flex items-center justify-between p-2.5 rounded-xl transition-all cursor-pointer ${
                  isViewing 
                    ? 'bg-primary-500/15 text-primary-200' 
                    : 'bg-dark-850/60 hover:bg-dark-800 text-zinc-400'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <button onClick={(e) => { e.stopPropagation(); handleCheckboxChange(s.id); }} className="text-zinc-500 hover:text-zinc-300 shrink-0">
                    {isSelected ? <CheckSquare className="w-4.5 h-4.5 text-primary-500" /> : <Square className="w-4.5 h-4.5" />}
                  </button>
                  <div className="truncate">
                    <p className="font-semibold text-zinc-200 text-xs truncate leading-snug">{s.name}</p>
                    <p className="text-[10px] text-zinc-550 font-mono mt-0.5">{s.registerNo}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {!s.photoPath && <AlertTriangle className="w-4.5 h-4.5 text-rose-500" />}
                  <button
                    onClick={(e) => { e.stopPropagation(); handleSingleExport(s); }}
                    className="p-1 hover:bg-zinc-800 rounded text-[9px] font-bold text-zinc-350 flex items-center bg-dark-900"
                    title="Export Card"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="p-3 bg-[#121214]/80 text-[10px] text-zinc-500 text-center font-bold">
          Total: {students.length} &bull; Selected: {students.filter(s => selectedStudents[s.id]).length}
        </div>
      </div>

      {/* COLUMN 2: LIVE CARD PREVIEW (clean borderless outer container) */}
      <div className="flex-1 flex flex-col rounded-2xl bg-[#141416]/50 overflow-hidden relative shadow-lg">
        <header className="h-12 bg-[#141416] flex items-center justify-between px-4">
          <span className="font-extrabold text-zinc-200 text-xs uppercase tracking-wider flex items-center gap-1">
            <Eye className="w-4 h-4 text-primary-500" /> Live Render Preview
          </span>
          <span className="text-[10px] bg-dark-900 px-2 py-0.5 rounded text-zinc-400 font-mono">
            Card {activeStudentIndex + 1} of {students.length}
          </span>
        </header>

        <div className="flex-1 overflow-auto flex items-center justify-center p-8 bg-[#121214]">
          <div 
            className="relative shadow-2xl rounded-xl bg-zinc-900 overflow-hidden"
            style={{ 
              width: cardW * displayScale * zoom, 
              height: cardH * displayScale * zoom 
            }}
          >
            <div style={{ width: cardW, height: cardH, transform: `scale(${displayScale * zoom})`, transformOrigin: 'top left' }}>
              <canvas ref={previewCanvasRef} />
            </div>
          </div>
          <div className="hidden"><canvas ref={hiddenCanvasRef} /></div>
        </div>

        {/* Zoom & Nav bar */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-[#141416]/95 p-1.5 rounded-xl shadow-2xl backdrop-blur-md">
          <button onClick={prevStudent} disabled={activeStudentIndex === 0} className="w-7 h-7 flex items-center justify-center rounded-lg bg-zinc-850 hover:bg-zinc-800 disabled:opacity-20 text-zinc-300">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-[10px] text-zinc-450 px-1 font-mono font-bold">Record {activeStudentIndex + 1}</span>
          <button onClick={nextStudent} disabled={activeStudentIndex === students.length - 1} className="w-7 h-7 flex items-center justify-center rounded-lg bg-zinc-850 hover:bg-zinc-800 disabled:opacity-20 text-zinc-300">
            <ChevronRight className="w-4 h-4" />
          </button>
          <div className="w-px h-4 bg-zinc-800 mx-1"></div>
          <button onClick={() => setZoom(prev => Math.max(0.2, Number((prev - 0.1).toFixed(1))))} className="w-7 h-7 flex items-center justify-center rounded-lg bg-zinc-800 text-zinc-450">
            <Minus className="w-3.5 h-3.5" />
          </button>
          <span className="text-[10px] text-zinc-300 px-1 font-mono font-bold w-12 text-center">{Math.round(zoom * 100)}%</span>
          <button onClick={() => setZoom(prev => Math.min(3, Number((prev + 0.1).toFixed(1))))} className="w-7 h-7 flex items-center justify-center rounded-lg bg-zinc-800 text-zinc-450">
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* COLUMN 3: EXPORT PANEL (flat shadow container) */}
      <div className="w-full lg:w-80 flex flex-col rounded-2xl bg-[#141416] p-4 shrink-0 overflow-y-auto shadow-lg">
        <div className="space-y-4">
          <h3 className="font-extrabold text-zinc-200 text-xs uppercase tracking-wider pb-3 flex items-center gap-1.5 border-b border-zinc-850">
            <FileDown className="w-4 h-4 text-primary-500" /> Export Options
          </h3>

          <div>
            <label className="text-[9px] text-zinc-550 font-bold uppercase block mb-1">Target Format</label>
            <select
              value={exportType}
              onChange={(e) => setExportType(e.target.value as any)}
              className="w-full bg-dark-850 border-none rounded-lg px-2.5 py-2.5 text-xs text-zinc-300 focus:outline-none"
            >
              <option value="pdf">Print PDF (Aggregated sheets)</option>
              <option value="png">ZIP Package (Individual High-res PNGs)</option>
              <option value="both">PDF Sheets + ZIP PNG Package</option>
            </select>
          </div>

          <div>
            <label className="text-[9px] text-zinc-550 font-bold uppercase block mb-1">Output Folder</label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                placeholder="Ask folder location on export"
                value={exportFolder || ''}
                className="flex-1 bg-dark-850 border-none rounded-lg px-2.5 py-2 text-[11px] focus:outline-none truncate text-zinc-450"
              />
              <button onClick={handleSelectExportFolder} className="bg-zinc-800 hover:bg-zinc-750 px-3 py-1.5 rounded-lg text-xs font-bold text-zinc-300 shrink-0">
                Browse
              </button>
              {exportFolder && (
                <button onClick={handleClearExportFolder} className="text-red-400 hover:text-red-300 text-xs font-semibold">
                  Clear
                </button>
              )}
            </div>
          </div>

          <div>
            <label className="text-[9px] text-zinc-550 font-bold uppercase block mb-0.5">Naming Format Template</label>
            <input
              type="text"
              value={namingPattern}
              onChange={(e) => setNamingPattern(e.target.value)}
              className="w-full bg-dark-850 border-none rounded-lg px-2.5 py-2 text-xs text-zinc-250 focus:outline-none"
            />
          </div>

          {generating ? (
            <div className="bg-dark-900 rounded-xl p-3.5 space-y-3 shadow-md">
              <div className="flex justify-between text-xs text-zinc-400">
                <span className="font-semibold">Exporting cards...</span>
                <span className="font-bold text-primary-500">{progress}%</span>
              </div>
              <div className="w-full bg-dark-850 h-2 rounded-full overflow-hidden">
                <div style={{ width: `${progress}%` }} className="bg-primary-500 h-full transition-all duration-200" />
              </div>
              <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-550 border-t border-zinc-850 pt-2 font-semibold">
                <div className="flex items-center gap-1.5"><Zap className="w-3.5 h-3.5 text-amber-500" /><span>{cardsPerSecond} c/s</span></div>
                <div className="flex items-center gap-1.5"><Hourglass className="w-3.5 h-3.5 text-primary-500" /><span>{elapsedSeconds}s elapsed</span></div>
              </div>
            </div>
          ) : (
            <button
              onClick={handleBulkExport}
              className="w-full bg-primary-500 hover:bg-primary-650 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md text-xs tracking-wider uppercase"
            >
              <Play className="w-3.5 h-3.5 fill-white text-white" /> Run Bulk Export
            </button>
          )}
        </div>

        <div className="flex-1 flex flex-col min-h-0 mt-6 border-t border-zinc-850 pt-4">
          <span className="font-extrabold text-zinc-550 text-[10px] uppercase mb-2.5 flex items-center gap-1.5">
            <FolderOpen className="w-4 h-4 text-primary-500" /> Export History
          </span>
          <div className="flex-1 overflow-y-auto space-y-2">
            {exports.map((exp) => (
              <div key={exp.id} className="bg-dark-900 rounded-xl p-3 flex flex-col gap-2 shadow-sm">
                <div className="flex items-start justify-between gap-2 min-w-0">
                  <div className="truncate">
                    <p className="font-bold text-zinc-200 text-xs truncate">{exp.filename}</p>
                    <p className="text-[9px] text-zinc-550 font-semibold mt-0.5 truncate">{exp.type} &bull; {exp.count} files</p>
                  </div>
                  <button onClick={() => handleOpenFolder(exp.filePath)} className="bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded text-[9px] font-bold shrink-0 transition-colors">
                    Locate
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
